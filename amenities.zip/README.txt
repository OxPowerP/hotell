Template Name: LuxuryHotel
Template Author: Untree.co
Template License: https://creativecommons.org/licenses/by/3.0/
Author URI: https://untree.co/

Twitter: https://twitter.com/Untree_co
Facebook: https://web.facebook.com/Untree.co/


CREDITS

* jQuery
* Popper
* Bootstrap
* Fancybox
* Unsplash
* Owl Carousel
* AOS
* animateNumber
* Waypoints
* Google Fonts
* TweenMax
* ScrollMagic
* Swiper
* Jarallax
* Sticky